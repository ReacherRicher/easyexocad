declare module 'tailwindcss-rtl'
